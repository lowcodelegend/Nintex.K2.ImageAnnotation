* Add Text comments to annotations
* Add a delete button that shows when a comment is selected
* Allow circular annotations
* Show image in designtime view
* Allow image to be loaded from smartobject as well as URL
* Consider "tagging" as well as comments, SmO or static list of tags